from django.apps import AppConfig


class CashieringConfig(AppConfig):
    name = 'CASHIERING'
